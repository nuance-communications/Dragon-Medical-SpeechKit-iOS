//
//  NUSASessionDelegate.h
//  Dragon Medical SpeechKit
//
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//
//  SDK version: 5.0.289.101
//

#import <UIKit/UIKit.h>

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
/** @brief NUSASession delegate messages.
 
	@xmlonly<nmFramework>DragonMedicalSpeechKit</nmFramework>@endxmlonly
	@since 1.0
 
	Delegate messages sent by the NUSASession class to its delegate receiver. All messages 
	provided by the protocol are optional and can be implemented by the receiver. 
*/
@protocol NUSASessionDelegate <NSObject>
@optional

//////////////////////////////////////////////////////////////////////////////////////////
/// @name Recording sessions
//////////////////////////////////////////////////////////////////////////////////////////

/** @brief Sent after audio data recording has started.
	@since 1.0
	
	Sent to the delegate whenever a recording session is started.
 */
- (void) sessionDidStartRecording;

/** @brief Sent after audio data recording has stopped and standby mode disabled.
	@since 3..9
    Sent to the delegate in the following conditions:
    1. Standby mode is disabled and the recording session is stopped.
    2. An error occurs when starting the recording session.
    3. An error occurs starting standby mode.
    4. Long press on the microphone button of the SpeechBar when the microphone is in recording or standby mode.
 */
- (void) sessionDidStopRecording;

//////////////////////////////////////////////////////////////////////////////////////////
/// @name TTS
//////////////////////////////////////////////////////////////////////////////////////////

/** @brief Sent after speaking has started.
    @since 1.3
 
    Sent to the delegate whenever speaking is started.
    If a call to startSpeaking() cancels a previous call to startSpeaking(), this message is not sent again.
 */
- (void) sessionDidStartSpeaking;

/** @brief Sent after speaking has stopped.
    @since 1.3
 
    Sent to the delegate whenever speaking is finished. This message is sent when the session has finished speaking the provided text or stopSpeaking() is called. 
    If speaking is cancelled by another call to startSpeaking(), this message is only sent after the last text has been finished.
 */
- (void) sessionDidStopSpeaking;

//////////////////////////////////////////////////////////////////////////////////////////
/// @name Standby mode
//////////////////////////////////////////////////////////////////////////////////////////

/** @brief Sent after standby mode has started.
    @since 3.9
    Sent to the delegate in the following conditions:
    1.Standby mode enabled and started.
    2.Standby mode is enabled and the recording  session is stopped.
 */
- (void) sessionDidStartStandby;


@end
